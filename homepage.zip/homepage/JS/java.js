function changeRed()  {
    document.getElementById("page1").style.backgroundImage = "none";
    document.getElementById("page1").style.backgroundColor = "Red";
    document.getElementById("page2").style.backgroundImage = "none";
    document.getElementById("page2").style.backgroundColor = "Red";
};
function changeBlue() {
    document.getElementById("page1").style.backgroundImage = "none";
    document.getElementById("page1").style.backgroundColor = "Blue";
    document.getElementById("page2").style.backgroundImage = "none";
    document.getElementById("page2").style.backgroundColor = "Blue";
};
function changeOrange() {
    document.getElementById("page1").style.backgroundImage = "none";
    document.getElementById("page1").style.backgroundColor = "Orange";
    document.getElementById("page2").style.backgroundImage = "none";
    document.getElementById("page2").style.backgroundColor = "Orange";
};
function changeGreen() {
    document.getElementById("page1").style.backgroundImage = "none";
    document.getElementById("page1").style.backgroundColor = "Green";
    document.getElementById("page2").style.backgroundImage = "none";
    document.getElementById("page2").style.backgroundColor = "Green";
};
function changeYellow() {
    document.getElementById("page1").style.backgroundImage = "none";
    document.getElementById("page1").style.backgroundColor = "Yellow";
    document.getElementById("page2").style.backgroundImage = "none";
    document.getElementById("page2").style.backgroundColor = "Yellow";
};

function small() {
    document.getElementById("flex").style.fontSize = "10px";
    document.getElementById("header").style.fontSize = "10px";
};
function medium() {
    document.getElementById("flex").style.fontSize = "30px";
    document.getElementById("header").style.fontSize = "30px";
};
function large() {
    document.getElementById("flex").style.fontSize = "50px";
    document.getElementById("header").style.fontSize = "50px";
};

function initial() {
    update = JSON.parse(localStorage.getItem("new"));
    if (update === null) {
        update = [];
    }
    else {
        for (i = 0; i < update.length; i++) {
            list = document.getElementById("news");
            newadditon = document.createElement('li');
            newadditon.appendChild(document.createTextNode(update[i]));
            list.appendChild(newadditon);
        }
    }
};

initial();

function add() {
    input = document.forms["form"]["name"].value;
    update.push(input);
    localStorage.setItem("new", JSON.stringify(update));
};

function remove() {
    update.pop();
    localStorage.setItem("new", JSON.stringify(update));
};

const arr = ["GET STARTED", "I AM SARTHAK BANSAL", "I AM A LOVABLE PERSON"];
var currindex = 0;
var i = 0;

const typewriter = (event) => {
    if (i < 0) {
        setTimeout(typewriter, 10);
        i++;
    }
    else if (i < arr[currindex].length) {
        let obj = document.getElementById("gg");
        obj.innerHTML += arr[currindex][i];
        i = i + 1;
        setTimeout(typewriter, 80);
    }
    else if (i == arr[currindex].length) {
        setTimeout(typewriter, 2000)
        i++;
    }
    else {
        deletion();
    }
};


const deletion = (event) => {
    if (i > 1) {
        let obj = document.getElementById("gg");
        obj.innerHTML = obj.innerHTML.slice(0, i - 1);
        i = i - 1;
        setTimeout(deletion, 80);
    }
    else if (i == 1) {
        setTimeout(deletion, 1000);
        i--;
    }
    else {
        currindex = (currindex + 1) % (arr.length);
        typewriter();
    }
};

var t=typewriter();
