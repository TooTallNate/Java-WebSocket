const skillval = [
    {
        name: "dsa",
        level: "70"
    },
    {
        name: "cpro",
        level: "60"
    },
    {
        name: "dsm",
        level: "90"
    },
    {
        name: "javascript",
        level: "50"
    },
    {
        name: "css",
        level: "80"
    },
    {
        name: "python",
        level: "75"
    },
];

function skillbar() {

    let v = document.getElementsByClassName("inner");
    for (var i = 0; i < skillval.length; i++) {
        var lev = parseInt(skillval[i].level);
        v[skillval[i].name].style.width = lev + "%";
        
    }
}